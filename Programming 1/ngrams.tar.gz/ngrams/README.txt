This directory contains chen yang's work for homework 1. My uid is u0738066.

I used python2 to do the work.

To run the code, simply move to the current directory in the terminal and run the command "python program1.py train.txt", the program1.py contains answers for both question1 and question2. It would automatically generate answers to question1 and question2, which are stored in ngrams-test.trace and ngrams-gen.trace files, respectively.

To generate sentences using different seeds file, run the command ��python generate.py -gen seed.txt�� in the terminal. The output would be shown in the terminal, and the output would also be saved in genOutput.trace. If you do not wish to see the output in the terminal, simply comment #60-61 lines in generate.py file.

Thanks!
