I'm using Python2.7 to complete the programming assignment.
The codes are saved in the file named "viterbi.py". To run it, follow the format:
python viterbi.py probs.txt sents.txt 
The results of testing are saved in the file "viterbi-trace.txt"
I've run my code on lab1-15.eng machine. The code ran smoothly.

Thanks!
